import React from 'react'
import {Button} from 'react-bootstrap'
function CustomButton() {
  return (
    <div>
        <Button variant="primary">Primary</Button>
    </div>
  )
}

export default CustomButton